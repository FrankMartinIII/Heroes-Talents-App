//
//  TalentTree.swift
//  HeroesApp
//
//  Created by user178070 on 10/27/20.
//

import Foundation

struct TalentTree: Codable
{
    var one : [Talent]
    var four : [Talent]
    var seven : [Talent]
    var ten : [Talent]
    var thirteen : [Talent]
    var sixteen : [Talent]
    var twenty : [Talent]
    
    enum CodingKeys : String, CodingKey
    {
        case one = "1"
        case four = "4"
        case seven = "7"
        case ten = "10"
        case thirteen = "13"
        case sixteen = "16"
        case twenty = "20"
    }
 
 
}
