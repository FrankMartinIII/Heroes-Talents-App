//
//  HeroDataBrain.swift
//  HeroesApp
//
//  Created by user178070 on 11/10/20.
//

import Foundation

class HeroDataBrain
{
    var heroes : [Hero] = []
    var allHeroes : [String] = []
    init()
    {
        initializeAllHeroes()
        //var data = loadData("abathur")
        //heroes.append(data)
        for h in allHeroes
        {
            var data = loadData(h)
            heroes.append(data)
        }
    }
    
    func loadData(_ heroName : String)->Hero
    {
        print("loading data")
        if let fileLocation = Bundle.main.url(forResource: heroName, withExtension: "json", subdirectory: "hero")
        {
            do{
                print("in do")
                let data = try Data(contentsOf: fileLocation)
                let jsonDecoder = JSONDecoder()
                let anadata = try jsonDecoder.decode(Hero.self, from: data)
                //print (anadata.name)
                //print(anadata.talents)
                return anadata
            }
            
            catch{
                print(error)
            }
        }
        else
        {
            print("didnt find file")
            
        }
        var hero = Hero()
        return hero
    }
    
    func initializeAllHeroes()
    {
        allHeroes.append("abathur")
        allHeroes.append("alarak")
        allHeroes.append("ana")
        allHeroes.append("anduin")
        allHeroes.append("anubarak")
        allHeroes.append("artanis")
        allHeroes.append("arthas")
        allHeroes.append("auriel")
        allHeroes.append("azmodan")
        allHeroes.append("blaze")
        allHeroes.append("brightwing")
        allHeroes.append("cassia")
        allHeroes.append("chen")
        allHeroes.append("chogall")
        allHeroes.append("chromie")
        allHeroes.append("deathwing")
        allHeroes.append("deckard")
        allHeroes.append("dehaka")
        allHeroes.append("diablo")
        allHeroes.append("dva")
        allHeroes.append("etc")
        allHeroes.append("falstad")
        allHeroes.append("fenix")
        allHeroes.append("gall")
        allHeroes.append("garrosh")
        allHeroes.append("gazlowe")
        allHeroes.append("genji")
        allHeroes.append("greymane")
        allHeroes.append("guldan")
        allHeroes.append("hanzo")
        allHeroes.append("hogger")
        allHeroes.append("illidan")
        allHeroes.append("imperius")
        allHeroes.append("jaina")
        allHeroes.append("johanna")
        allHeroes.append("junkrat")
        allHeroes.append("kaelthas")
        allHeroes.append("kelthuzad")
        allHeroes.append("kerrigan")
        allHeroes.append("kharazim")
        allHeroes.append("leoric")
        allHeroes.append("lili")
        allHeroes.append("liming")
        allHeroes.append("lostvikings")
        allHeroes.append("ltmorales")
        allHeroes.append("lucio")
        allHeroes.append("lunara")
        allHeroes.append("maiev")
        allHeroes.append("malfurion")
        allHeroes.append("malganis")
        allHeroes.append("malthael")
        allHeroes.append("medivh")
        allHeroes.append("mei")
        allHeroes.append("mephisto")
        allHeroes.append("muradin")
        allHeroes.append("murky")
        allHeroes.append("nazeebo")
        allHeroes.append("nova")
        allHeroes.append("orphea")
        allHeroes.append("probius")
        allHeroes.append("qhira")
        allHeroes.append("ragnaros")
        allHeroes.append("raynor")
        allHeroes.append("rehgar")
        allHeroes.append("rexxar")
        allHeroes.append("samuro")
        allHeroes.append("sgthammer")
        allHeroes.append("sonya")
        allHeroes.append("stitches")
        allHeroes.append("stukov")
        allHeroes.append("sylvanas")
        allHeroes.append("tassadar")
        allHeroes.append("thebutcher")
        allHeroes.append("thrall")
        allHeroes.append("tracer")
        allHeroes.append("tychus")
        allHeroes.append("tyrael")
        allHeroes.append("tyrande")
        allHeroes.append("uther")
        allHeroes.append("valeera")
        allHeroes.append("valla")
        allHeroes.append("varian")
        allHeroes.append("whitemane")
        allHeroes.append("xul")
        allHeroes.append("yrel")
        allHeroes.append("zagara")
        allHeroes.append("zarya")
        allHeroes.append("zeratul")
        allHeroes.append("zuljin")
        //allHeroes.append("")
        
    }
    
}
