//
//  TalentPageViewController.swift
//  HeroesApp
//
//  Created by user178070 on 11/15/20.
//

import UIKit

class TalentPageViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate{

    override func viewDidLoad() {
        super.viewDidLoad()

        
        // Do any additional setup after loading the view.
        lblHeroName.text = curHero.name
        collectionView1.dataSource = self
        collectionView4.dataSource = self
        collectionView7.dataSource = self
        collectionView10.dataSource = self
        collectionView13.dataSource = self
        collectionView16.dataSource = self
        collectionView20.dataSource = self
        collectionView1.delegate = self
        collectionView4.delegate = self
        collectionView7.delegate = self
        collectionView10.delegate = self
        collectionView13.delegate = self
        collectionView16.delegate = self
        collectionView20.delegate = self
        //self.collectionView1.reloadData()
        //self.collectionView4.reloadData()
    }
    
    @IBOutlet weak var lblHeroName: UILabel!
    
    @IBOutlet weak var collectionView1: UICollectionView!
    
    
    @IBOutlet weak var collectionView4: UICollectionView!
    
    
    @IBOutlet weak var collectionView7: UICollectionView!
    
    
    @IBOutlet weak var collectionView10: UICollectionView!
    
    
    @IBOutlet weak var collectionView13: UICollectionView!
    
    
    @IBOutlet weak var collectionView16: UICollectionView!
    
    
    @IBOutlet weak var collectionView20: UICollectionView!

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("selected")
        
        var cell = collectionView.cellForItem(at: indexPath)
        var talentName : String = "novalue"
        var talentDescription : String = "novalue"
        
        if collectionView == collectionView1
        {
            talentName = curHero.talents!.one[indexPath.item].name
            
            talentDescription = curHero.talents!.one[indexPath.item].description
            
        }
        
        else if collectionView == collectionView4
        {
            talentName = curHero.talents!.four[indexPath.item].name
            
            talentDescription = curHero.talents!.four [indexPath.item].description
            
        }
        
        else if collectionView == collectionView7
        {
            talentName = curHero.talents!.seven[indexPath.item].name
            
            talentDescription = curHero.talents!.seven [indexPath.item].description
            
        }
        
        else if collectionView == collectionView10
        {
            talentName = curHero.talents!.ten[indexPath.item].name
            
            talentDescription = curHero.talents!.ten [indexPath.item].description
            
        }
        
        else if collectionView == collectionView13
        {
            talentName = curHero.talents!.thirteen[indexPath.item].name
            
            talentDescription = curHero.talents!.thirteen [indexPath.item].description
            
        }
        
        else if collectionView == collectionView16
        {
            talentName = curHero.talents!.sixteen[indexPath.item].name
            
            talentDescription = curHero.talents!.sixteen [indexPath.item].description
            
        }
        
        else if collectionView == collectionView20
        {
            talentName = curHero.talents!.twenty[indexPath.item].name
            
            talentDescription = curHero.talents!.twenty [indexPath.item].description
            
        }
        
        
        
        let myAlert = UIAlertController(title: talentName, message: talentDescription, preferredStyle: UIAlertController.Style.alert)
                        
        myAlert.addAction(UIAlertAction(title:"Close", style: UIAlertAction.Style.default, handler: {_ in collectionView.deselectItem(at: indexPath, animated: false)}))  //turns cell text back to black
                        
        self.present(myAlert, animated:true, completion: nil)
    }
    /*
    @objc func tap(_ sender: UITapGestureRecognizer)
    {
        let location = sender.location(in: self.collectionView1)
        
        let indexPath = self.collectionView1.indexPathForItem(at: location)
        if let index = indexPath
        {
            print("clicked")
        }
    }
 */
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        print("setting up a collection view")
        if collectionView == self.collectionView1
        {
            return curHero.talents!.one.count
        }
        else if collectionView == self.collectionView4
        {
            print("func1")
            return curHero.talents!.four.count
        }
        
        else if collectionView == self.collectionView7
        {
            print("func1")
            return curHero.talents!.seven.count
        }
        
        else if collectionView == self.collectionView10
        {
            print("func1")
            return curHero.talents!.ten.count
        }
        
        else if collectionView == self.collectionView13
        {
            print("func1")
            return curHero.talents!.thirteen.count
        }
        
        else if collectionView == self.collectionView16
        {
            print("func1")
            return curHero.talents!.sixteen.count
        }
        
        else if collectionView == self.collectionView20
        {
            print("func1")
            return curHero.talents!.twenty.count
        }
        print("missed if statements")
        return 0
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        print("setting up a cell view")
        if collectionView == self.collectionView1
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "customCell", for: indexPath) as! CustomCollectionViewCell
            
            cell.lblText.text = curHero.talents!.one[indexPath.row].name
            var img = "talents/" + curHero.talents!.one[indexPath.row].icon
            cell.imageView?.image = UIImage(named: img)
            
            cell.talent = curHero.talents!.one[indexPath.row]
            
            print("returning cell",  curHero.talents!.one[indexPath.row].name)
            //cell.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(tap(_:))))
            return cell
        }
        
        else if collectionView == self.collectionView4
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "customCell", for: indexPath) as! CustomCollectionViewCell
            
            cell.lblText.text = curHero.talents!.four[indexPath.row].name
            var img = "talents/" + curHero.talents!.four[indexPath.row].icon
            cell.imageView?.image = UIImage(named: img)
            print("returning cell",  curHero.talents!.four[indexPath.row].name)
            return cell
        }
        
        else if collectionView == self.collectionView7
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "customCell", for: indexPath) as! CustomCollectionViewCell
            
            cell.lblText.text = curHero.talents!.seven[indexPath.row].name
            var img = "talents/" + curHero.talents!.seven[indexPath.row].icon
            cell.imageView?.image = UIImage(named: img)
            print("returning cell",  curHero.talents!.seven[indexPath.row].name)
            return cell
        }
        
        else if collectionView == self.collectionView10
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "customCell", for: indexPath) as! CustomCollectionViewCell
            
            cell.lblText.text = curHero.talents!.ten[indexPath.row].name
            var img = "talents/" + curHero.talents!.ten[indexPath.row].icon
            cell.imageView?.image = UIImage(named: img)
            print("returning cell",  curHero.talents!.ten[indexPath.row].name)
            return cell
        }
        
        else if collectionView == self.collectionView13
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "customCell", for: indexPath) as! CustomCollectionViewCell
            
            cell.lblText.text = curHero.talents!.thirteen[indexPath.row].name
            var img = "talents/" + curHero.talents!.thirteen[indexPath.row].icon
            cell.imageView?.image = UIImage(named: img)
            print("returning cell",  curHero.talents!.thirteen[indexPath.row].name)
            return cell
        }
        
        else if collectionView == self.collectionView16
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "customCell", for: indexPath) as! CustomCollectionViewCell
            
            cell.lblText.text = curHero.talents!.sixteen[indexPath.row].name
            var img = "talents/" + curHero.talents!.sixteen[indexPath.row].icon
            cell.imageView?.image = UIImage(named: img)
            print("returning cell",  curHero.talents!.sixteen[indexPath.row].name)
            return cell
        }
        
        else
        {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "customCell", for: indexPath) as! CustomCollectionViewCell
            
            cell.lblText.text = curHero.talents!.twenty[indexPath.row].name
            var img = "talents/" + curHero.talents!.twenty[indexPath.row].icon
            cell.imageView?.image = UIImage(named: img)
            print("returning cell",  curHero.talents!.twenty[indexPath.row].name)
            return cell
        }
    }

}
