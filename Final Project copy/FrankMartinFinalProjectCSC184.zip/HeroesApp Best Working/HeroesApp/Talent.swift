//
//  Talent.swift
//  HeroesApp
//
//  Created by user178070 on 11/10/20.
//

import Foundation

struct Talent : Codable
{
    var tooltipId: String
    var talentTreeId: String
    var name : String
    var description: String
    var icon: String
}
