//
//  CustomCollectionViewCell.swift
//  HeroesApp
//
//  Created by user178070 on 11/15/20.
//

import UIKit

class CustomCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
        
    
    @IBOutlet weak var lblText: UILabel!
    
    var talent : Talent? = nil
}
