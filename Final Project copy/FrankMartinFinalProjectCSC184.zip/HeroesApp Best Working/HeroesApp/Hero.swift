//
//  Hero.swift
//  HeroesApp
//
//  Created by user178070 on 10/27/20.
//

import Foundation

struct Hero: Codable
{
    var name:String = " "
    var icon:String = " "
    var talents:TalentTree? = nil
    //var abilities: AbilityList?
}
