//
//  ViewController.swift
//  HeroesApp
//
//  Created by user178070 on 10/27/20.
//

import UIKit
//var heroesData = HeroDataBrain()

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print("running")
        for h in heroesData.heroes
        {
            print(h.name)
        }
        
        
    }
    
    


}

