//
//  AbilityList.swift
//  HeroesApp
//
//  Created by user178070 on 12/15/20.
//
/*
import Foundation


struct AbilityList: Codable
{
    var heroAbilities : [Talent]

    
    enum CodingKeys : String, CodingKey
    {
        case heroAbilities = name  //name cant be accessed from here...
        
    }
 
 
}
*/
