//
//  TableViewController.swift
//  HeroesApp
//
//  Created by user178070 on 11/10/20.
//

import UIKit
var heroesData = HeroDataBrain()
var curHero = Hero()
class TableViewController: UITableViewController {

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func numberOfSections(in tableView:UITableView)->Int{
        return 1
    }
    
    override func tableView(_ tableView : UITableView, numberOfRowsInSection: Int)->Int{
        return heroesData.heroes.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath : IndexPath)->UITableViewCell{
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        let row = indexPath.row
        
        cell.textLabel?.text = heroesData.heroes[row].name
        
        var img = "heroes/" + heroesData.heroes[row].icon
        
        cell.imageView?.image = UIImage(named: img)
        
        
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        curHero = heroesData.heroes[indexPath.row]
        performSegue(withIdentifier: "segue1", sender: self)
    }
    
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
